data  = input()

print(data)