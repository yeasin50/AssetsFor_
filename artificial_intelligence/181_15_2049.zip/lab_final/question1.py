data  = input()

print(data)