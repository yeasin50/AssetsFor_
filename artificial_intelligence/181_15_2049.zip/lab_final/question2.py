a = int(input("a: "))
b = int(input("b: "))

print(a,"+",b, "= ", (a+b))
print(a,"-",b, "= ", (a-b))
print(a,"x",b, "= ", (a*b))
print(a,"/",b, "= ", (a/b))