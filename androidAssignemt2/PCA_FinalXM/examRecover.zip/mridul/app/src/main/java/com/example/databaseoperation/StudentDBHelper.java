package com.example.databaseoperation;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class StudentDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentDatabase.db";
    private static final String TABLE_NAME = "studentTable";
    private static final String ID = "_id";
    private static final String NAME = "std_name";
    private static final String PHONE = "phone";
    private static final String SECTION = "section";
    public static final String DEPARTMENT ="department";
    private static final int VERSION = 1;

     SQLiteDatabase sqLiteDatabase;

    public Context context;
    public StudentDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("+
                ID + " VARCHAR(250) PRIMARY KEY, " +
                NAME+" TEXT ,"+
                PHONE +" TEXT, "+
                SECTION+" TEXT," +
                DEPARTMENT +" TEXT" +
                ")";

        try {
            db.execSQL(CREATE_TABLE);
        } catch (Exception e) {
            Toast.makeText(context, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
            onCreate(db);
        } catch (Exception e) {
            Toast.makeText(context, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public long insertData(Student student){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID, student.id);
        contentValues.put(NAME, student.name);
        contentValues.put(PHONE, student.phone);
        contentValues.put(SECTION, student.section);
        contentValues.put(DEPARTMENT, student.department);
        long rowID = sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        return rowID;
    }

    public Cursor viewData(){
       SQLiteDatabase  sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM "+TABLE_NAME,null);
        return  cursor;
    }

    public  long  delete(String id){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

       long rowID= sqLiteDatabase.delete(TABLE_NAME, ID +"=?", new String[]{id});
        return  rowID;
    }

}
