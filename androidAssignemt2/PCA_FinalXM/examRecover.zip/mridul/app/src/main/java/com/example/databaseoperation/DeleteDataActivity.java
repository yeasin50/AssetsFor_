package com.example.databaseoperation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteDataActivity extends AppCompatActivity {

    private EditText editText;
    private Button button;

    StudentDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_data);

        setTitle("Deletion");
        dbHelper = new StudentDBHelper(this);

        editText = findViewById(R.id.editTextDeleteEntry);
        button = findViewById(R.id.btnDelete);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String deleteEntry = editText.getText().toString().trim();

                if(deleteEntry.isEmpty()) {
                   showToast("Enter id to perform deletion");
                    return;
                }

               long result = dbHelper.delete(deleteEntry);
                if(result>0)showToast("Deleted");
                else showToast("Failed to delete");
            }
        });
    }

    void showToast(String msg){
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}