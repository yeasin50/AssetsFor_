package com.example.databaseoperation;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

public class ViewDataActivity extends AppCompatActivity {

    TextView textViewData;
    StudentDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);

        setTitle("Stored DB");
        dbHelper = new StudentDBHelper(this);

        textViewData = findViewById(R.id.textViewDataView);

        try {
            textViewData.setText(getDatabase());
        }catch (Exception e){
            textViewData.setText("Some Error happened");
        }
    }

    String getDatabase(){
        Cursor cursor = dbHelper.viewData();
        if(cursor.getCount()==0){
            return "No Stored Database found!\n Save data and come again.";
        }

        StringBuffer stringBuffer = new StringBuffer();
        while (cursor.moveToNext()){
            stringBuffer.append("Id: "+ cursor.getString(0)+"\n");
            stringBuffer.append("Name: "+ cursor.getString(1)+"\n");
            stringBuffer.append("Phone: "+ cursor.getString(2)+"\n");
            stringBuffer.append("Section: "+ cursor.getString(3)+"\n");
            stringBuffer.append("Department: "+ cursor.getString(4)+"\n\n");
        }
        return  stringBuffer.toString();
    }

}