package com.example.databaseoperation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {

    private EditText editTextID, editTextName, editTextPhone, editTextSection,editTextDepartment;
    private Button btnSaveDatabase;

    StudentDBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        setTitle("Insertion");
        dbHelper = new StudentDBHelper(this);

        editTextID = findViewById(R.id.ediTextID);
        editTextName = findViewById(R.id.ediTextName);
        editTextPhone = findViewById(R.id.ediTextPhone);
        editTextSection = findViewById(R.id.ediTextSection);
        editTextDepartment = findViewById(R.id.ediTextDepartment);

        btnSaveDatabase = findViewById(R.id.btnSave);

        btnSaveDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = editTextID.getText().toString().trim();
                String name = editTextName.getText().toString().trim();
                String phone = editTextPhone.getText().toString().trim();
                String section = editTextPhone.getText().toString().trim();
                String department = editTextDepartment.getText().toString().trim();

                if(id.isEmpty() || name.isEmpty()|| phone.isEmpty() || section.isEmpty() || department.isEmpty()){
                    showToast("Fill the form!");
                    return;
                }

                Student student = new Student(id, name,phone,section,department);
               long rowID = dbHelper.insertData(student);

               if(rowID>0){
                  showToast("Data stored!");
               }else   showToast("Failed to stored!");

            }
        });
    }
    void showToast(String msg){
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}