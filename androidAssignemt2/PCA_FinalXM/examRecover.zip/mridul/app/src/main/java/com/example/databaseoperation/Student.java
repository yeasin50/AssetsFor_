package com.example.databaseoperation;

public class Student {
    String id;
    String name;
    String phone;
    String section;
    String department;

    public Student(String id, String name, String phone, String section, String department) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.section = section;
        this.department = department;
    }
}
